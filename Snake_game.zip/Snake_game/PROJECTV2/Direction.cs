﻿
namespace PROJECTV2
{
    public class Direction
    {
        //definição dos controlos de movimento (esquerda, direita, baixo e cima) que a cobra poderá ter na grid (linha, coluna) 
        //quando clicamos no left por exemplo a cobra só se movimentará no eixo do x 1 valor para a esquerda, ou seja para -1 
        public readonly static Direction Left = new Direction(0, -1); 
        public readonly static Direction Right = new Direction(0, 1);
        public readonly static Direction Down = new Direction(1, 0);
        public readonly static Direction Up = new Direction(-1, 0);

        //definição da direção da snake na grid com uso das colunas e linhas
        public int RowOffset { get; }
        public int ColOffset { get; }

        private Direction(int rowOffset, int colOffset) 
        { 
            RowOffset = rowOffset;
            ColOffset = colOffset;
        }

        public Direction Opposite () 
        {
            return new Direction(-RowOffset, -ColOffset);
        }

        //reescreve a classe com atribuição de novos valores
        public override bool Equals(object obj)
        {
            return obj is Direction direction &&
                   RowOffset == direction.RowOffset &&
                   ColOffset == direction.ColOffset;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(RowOffset, ColOffset);
        }

        public static bool operator ==(Direction left, Direction right)
        {
            return EqualityComparer<Direction>.Default.Equals(left, right);
        }

        public static bool operator !=(Direction left, Direction right)
        {
            return !(left == right);
        }
    }
}
