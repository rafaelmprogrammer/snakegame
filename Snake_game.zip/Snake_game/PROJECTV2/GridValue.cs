﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJECTV2
{
    public enum GridValue //classe com os elementos que aparecem na grid/grelha/tabuleiro

    {
        Empty, //Espaços sem comida ou a snake
        Snake, //Espaços ocupados pela cobra
        Food, //Espaços ocupados pela comida
        Outside //Espaço fora da gride que foi utilizado para quando a snake tenta sair da grid 
    }
}
