﻿using System.Windows.Documents;

namespace PROJECTV2
{
    //classe representativa das posições na grid com base numa coluna e numa linha 
    public class Position
    {
        public int Row { get; }
        public int Col { get; }

        public Position (int row, int col)
        {
            Row = row;
            Col = col;
        }

        //retorna a posição em que a cobra fica após ter sido indicada uma direção, ganhando uma nova posição
        public Position Translate(Direction dir)
        {
            return new Position (Row + dir.RowOffset, Col + dir.ColOffset);
            
        }
        //comparação entre posições nas colunas e linhas e os objetos do jogo (cobra) . //reescreve a classe com atribuição de novos valores
        public override bool Equals(object obj)
        {
            return obj is Position position &&
                   Row == position.Row &&
                   Col == position.Col;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Row, Col);
        }

        public static bool operator ==(Position left, Position right)
        {
            return EqualityComparer<Position>.Default.Equals(left, right);
        }

        public static bool operator !=(Position left, Position right)
        {
            return !(left == right);
        }
    }
}
